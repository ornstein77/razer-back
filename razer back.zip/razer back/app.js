const express =require ('express');
const app = express();
const port = 3001;



app.use(express.static('views'))




app.use ('/',function(_,res){
    res.render('index.html')
})

app.listen(port, '127.0.0.1',function(_,res){
  console.log ('Server start http://localhost:%s',port)
})