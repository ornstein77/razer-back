const swiper = new Swiper('.swiper', {
    
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    
    slidesPerView:1,
    // spaceBetween: 30,
    initialSlide:1
    
});  
gsap.to(".banner__content-text", { x: -200, duration: 1});

const miceBtn = document.getElementById('miceBtn');
const bordBtn = document.getElementById('bordBtn');
const podsBtn = document.getElementById('podsBtn');


// razdel
const mice = document.getElementById('mice');
const bord= document.getElementById('bord');
const pods = document.getElementById('pods');

// script
const moveTo = new MoveTo({
  
  tolerance: 10,
  duration: 1000,
  easing: 'easeOutQuart'
});

miceBtn.addEventListener('click', (event) => {
  
  event.preventDefault(); 
  moveTo.move(mice); 
});

bordBtn.addEventListener('click', (event) => {
  event.preventDefault(); 
  moveTo.move(bord); 
});
podsBtn.addEventListener('click', (event) => {
  event.preventDefault(); 
  moveTo.move(pods); 
});


tippy('[data-tippy-content]');

